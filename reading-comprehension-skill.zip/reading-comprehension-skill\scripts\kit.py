# -*- coding: utf-8 -*-
"""figure_kit —— 设计单位显示列表渲染器（Pillow 超采样 + 同源 SVG + PDF）

设计约定
--------
* 所有坐标都是「设计单位」：默认画布 1920 x 1200（16:10），
  与最终像素比例一致，所以版式可以按肉眼像素直觉来写。
* 先往 OPS 里追加绘图指令（rrect / line / cubic / circle / text / run），
  再统一交给 render_pil / render_svg 输出 —— 位图与矢量永远同源。
* 位图按 SUPERSAMPLE 倍放大绘制，最后 LANCZOS 缩小，边缘不发虚。
* 文字大小、行距、间距全部以设计单位给出；字号单位 = 像素（设计单位）。

依赖
----
    Pillow >= 9（ImageFont.set_variation_by_name 需要 >= 9.1）

字体
----
默认自动在常见字体目录里找 Noto Sans SC / Noto Serif SC / Cascadia Mono，
找不到时退到系统里有 CJK 的字体。可用环境变量 FIGKIT_FONT_DIR 指定目录。
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFont

# --------------------------------------------------------------------------
# canvas
# --------------------------------------------------------------------------
W, H = 1920, 1200
S = 3                      # 位图超采样倍数
PAGE = "#FCFBF9"           # 页面底色

# --------------------------------------------------------------------------
# palette (design system —— 改这里就能换整套风格)
# --------------------------------------------------------------------------
CARD = "#FFFFFF"
BORDER = "#E7E3DB"
HAIR = "#EEEBE4"
INK = "#0E1626"
BODY = "#1F2937"
MUTED = "#5A6577"
FAINT = "#909CAC"
FAINT2 = "#B4BDC9"
ZEBRA = "#FAF9F6"
RULE = "#DCD8CF"

SERIF, SANS, MONO = "serif", "sans", "mono"

# 语义化配色：实体类型 / 强调色（模板可覆盖）
ENT = {
    "TIME": dict(zh="时间", c="#A75C06", bg="#FDEFC6", line="#E9A23B",
                 desc="日期、时刻与时段"),
    "ORG": dict(zh="机构", c="#1D4ED8", bg="#DCE8FE", line="#6C9BF2",
                desc="公司、高校与政府机构"),
    "LOC": dict(zh="地名", c="#06704F", bg="#CFF0E2", line="#4FBE95",
                desc="国家、城市与区域"),
    "PROD": dict(zh="产品", c="#6D28D9", bg="#EBE4FE", line="#A98BF5",
                 desc="软件、设备与型号"),
}

# --------------------------------------------------------------------------
# fonts
# --------------------------------------------------------------------------
_FONT_DIRS = [
    os.environ.get("FIGKIT_FONT_DIR", ""),
    r"C:\Windows\Fonts",
    "/usr/share/fonts",
    "/usr/local/share/fonts",
    os.path.expanduser("~/.fonts"),
    "/System/Library/Fonts",
    "/Library/Fonts",
    os.path.expanduser("~/Library/Fonts"),
]

_SERIF_FILES = ["NotoSerifSC-VF.ttf", "NotoSerifSC-Regular.ttf",
                "SourceHanSerifSC-Regular.otf", "NotoSerifCJK-Regular.ttc",
                "simsun.ttc", "STSong.ttf", "Songti.ttc", "DejaVuSerif.ttf"]
_SANS_FILES = ["NotoSansSC-VF.ttf", "NotoSansSC-Regular.ttf",
               "SourceHanSansSC-Regular.otf", "NotoSansCJK-Regular.ttc",
               "msyh.ttc", "msyhbd.ttc", "PingFang.ttc", "simhei.ttf",
               "DejaVuSans.ttf"]
_MONO_FILES = ["CascadiaMono.ttf", "CascadiaCode.ttf", "consola.ttf",
               "Consolas.ttf", "DejaVuSansMono.ttf", "Menlo.ttc",
               "CourierNew.ttf"]

# 变量字体实例名：serif: Regular/Medium/SemiBold/Bold；sans: Regular/Medium/Bold
_VAR = {
    ("serif", 400): "Regular", ("serif", 500): "Medium",
    ("serif", 600): "SemiBold", ("serif", 700): "Bold",
    ("sans", 400): "Regular", ("sans", 500): "Medium",
    ("sans", 700): "Bold",
    ("mono", 400): None, ("mono", 500): None,
}


def _find(files):
    for d in _FONT_DIRS:
        if not d or not os.path.isdir(d):
            continue
        for name in files:
            p = os.path.join(d, name)
            if os.path.exists(p):
                return p
    # 再扫一遍目录里的模糊匹配（Linux 下常见 NotoSansCJK-Regular.ttc 变体名）
    for d in _FONT_DIRS:
        if not d or not os.path.isdir(d):
            continue
        try:
            entries = os.listdir(d)
        except OSError:
            continue
        for name in files:
            stem = os.path.splitext(name)[0].split("-")[0].lower()
            for e in entries:
                if stem and stem in e.lower():
                    return os.path.join(d, e)
    return None


FONT_PATHS = {
    "serif": _find(_SERIF_FILES),
    "sans": _find(_SANS_FILES),
    "mono": _find(_MONO_FILES),
}

_cache = {}


def font(fam, wt, size):
    """取字体对象；size 是设计单位字号，内部自动乘 S。"""
    key = (fam, wt, round(size, 2))
    if key in _cache:
        return _cache[key]
    path = FONT_PATHS.get(fam)
    if not path:
        raise RuntimeError(
            "figure_kit: 找不到字体族 %r。请安装 Noto Sans SC / Noto Serif SC / "
            "Cascadia Mono，或用环境变量 FIGKIT_FONT_DIR 指向字体目录。" % fam)
    f = ImageFont.truetype(path, max(1, int(round(size * S))))
    var = _VAR.get((fam, wt))
    if var:
        try:
            f.set_variation_by_name(var)
        except Exception:
            pass
    _cache[key] = f
    return f


def font_report():
    """打印实际选中的字体，便于排查环境问题。"""
    for fam in ("serif", "sans", "mono"):
        print(f"  {fam:5s} -> {FONT_PATHS.get(fam)}")
    return FONT_PATHS


def tw(text, fam=SANS, wt=400, size=13, ls=0.0):
    """字符串宽度（设计单位）。"""
    if not text:
        return 0.0
    f = font(fam, wt, size)
    return f.getlength(text) / S + ls * (len(text) - 1)


def th(fam=SANS, wt=400, size=13, sample="国Ag"):
    """字符串高度（设计单位），用 bbox 估算。"""
    f = font(fam, wt, size)
    b = f.getbbox(sample)
    return (b[3] - b[1]) / S


def vcenter(fam, wt, size, sample="国"):
    """把「垂直中心」换算成基线 y 的偏移量：baseline = center + vcenter(...)。"""
    f = font(fam, wt, size)
    b = f.getbbox(sample)
    return -(b[1] + b[3]) / (2.0 * S)


# --------------------------------------------------------------------------
# display list
# --------------------------------------------------------------------------
OPS = []


def reset():
    del OPS[:]


def rrect(x0, y0, x1, y1, fill=None, stroke=None, sw=1.0, r=0):
    OPS.append(dict(t="rrect", x0=x0, y0=y0, x1=x1, y1=y1,
                    fill=fill, stroke=stroke, sw=sw, r=r))


def line(x0, y0, x1, y1, color, w=1.0):
    OPS.append(dict(t="line", x0=x0, y0=y0, x1=x1, y1=y1, color=color, w=w))


def hline(x0, x1, y, color, w=1.0):
    line(x0, y, x1, y, color, w)


def vline(x, y0, y1, color, w=1.0):
    line(x, y0, x, y1, color, w)


def cubic(p0, p1, p2, p3, color, w=1.0):
    OPS.append(dict(t="cubic", pts=(p0, p1, p2, p3), color=color, w=w))


def circle(cx, cy, r, fill=None, stroke=None, sw=1.0):
    OPS.append(dict(t="circle", cx=cx, cy=cy, r=r,
                    fill=fill, stroke=stroke, sw=sw))


def text(x, y, s, fam=SANS, wt=400, size=13, color=INK, anchor="l",
         ls=0.0, halo=None, halo_w=0.0):
    """x,y 是基线位置；anchor: l=左对齐 / m=水平居中 / r=右对齐。"""
    if s == "" or s is None:
        return
    OPS.append(dict(t="text", x=x, y=y, s=str(s), fam=fam, wt=wt, size=size,
                    color=color, anchor=anchor, ls=ls,
                    halo=halo, halo_w=halo_w))


def run(x, y, parts, anchor="l"):
    """一段混排文本：parts=[(text, fam, wt, size, color), ...]；返回结束 x。"""
    total = sum(tw(p[0], p[1], p[2], p[3]) for p in parts)
    if anchor == "m":
        x -= total / 2.0
    elif anchor == "r":
        x -= total
    for s, fam, wt, size, color in parts:
        text(x, y, s, fam, wt, size, color)
        x += tw(s, fam, wt, size)
    return x


# --------------------------------------------------------------------------
# 常用组合件（模板共用）
# --------------------------------------------------------------------------
_WIDE_EXTRA = {0x2014, 0x2026}


def is_wide(ch):
    o = ord(ch)
    return o > 0x2E80 or 0x2018 <= o <= 0x201F or o in _WIDE_EXTRA


def mono_line(x, y, segs, cw, size=11.0):
    """等宽行；CJK 字按 2 个等宽格居中放置（Cascadia Mono 没有中文字形）。

    segs: [(color, text), ...]；cw: 单个等宽字符宽（设计单位）。
    返回行尾 x。
    """
    cx = x
    for color, s in segs:
        i, n = 0, len(s)
        while i < n:
            ch = s[i]
            if is_wide(ch):
                text(cx + cw, y, ch, SANS, 400, size, color, anchor="m")
                cx += 2 * cw
                i += 1
            else:
                j = i
                while j < n and not is_wide(s[j]):
                    j += 1
                text(cx, y, s[i:j], MONO, 400, size, color)
                cx += cw * (j - i)
                i = j
    return cx


def flow_units(xs, ys, units, xmax, line_h=18.0,
               tag_col=BODY, gl_col=MUTED, sep=14.0,
               tag_size=10.0, gl_size=10.5):
    """把 "tag 释义 · tag 释义 …" 自动折行塞进 [xs, xmax]；返回最后一行的 y。"""
    x, y = xs, ys
    first = True
    for tag, gl in units:
        wtag = tw(tag, MONO, 400, tag_size)
        wgl = tw(gl, SANS, 400, gl_size)
        need = (0 if first else sep) + wtag + 4 + wgl
        if not first and x + need > xmax:
            x, y, first = xs, y + line_h, True
        if not first:
            text(x, y, "·", SANS, 400, 10, FAINT2)
            x += sep
        text(x, y, tag, MONO, 400, tag_size, tag_col)
        x += wtag + 4
        text(x, y, gl, SANS, 400, gl_size, gl_col)
        x += wgl
        first = False
    return y


def card(x0, y0, w, h, num, zh, en,
         fill=CARD, stroke=BORDER, r=14,
         num_col=MUTED, zh_col=INK, en_col=FAINT2):
    """标准卡片：圆角框 + 「② 标题 + 英文副标」页眉 + 细分隔线。

    返回内容起始 y（= y0 + 86）。
    """
    rrect(x0, y0, x0 + w, y0 + h, fill=fill, stroke=stroke, sw=1, r=r)
    x = x0 + 22
    if num:                                   # 传空串则不占编号位
        text(x, y0 + 45, num, SANS, 700, 13, num_col)
        x += tw(num, SANS, 700, 13) + 8
    text(x, y0 + 45, zh, SANS, 700, 14, zh_col)
    x += tw(zh, SANS, 700, 14) + 9
    text(x, y0 + 45, en, MONO, 400, 9, en_col, ls=1.4)
    line(x0 + 22, y0 + 61, x0 + w - 22, y0 + 61, HAIR, 1)
    return y0 + 86


def section_label(x, y, num, zh, en, meta=None, right=1840):
    """① 区段标题行：编号 + 中文标题 + 英文副标（+ 右侧 meta 混排）。"""
    text(x, y, num, SANS, 700, 13.5, INK)
    text(x + 26, y, zh, SANS, 700, 14, INK)
    lx = x + 26 + tw(zh, SANS, 700, 14) + 14
    text(lx, y, en, MONO, 400, 9.2, FAINT2, ls=1.1)
    if meta:
        run(right, y, meta, anchor="r")


def page_header(eyebrow, eyebrow_zh, title, subtitle,
                x=80, right=1840, rule_y=197, title_size=40):
    """页眉：小字 eyebrow + 衬线大标题 + 无衬线副标题 + 横向细线。"""
    text(x, 71, eyebrow, MONO, 400, 10.5, FAINT, ls=2.2)
    ek = x + tw(eyebrow, MONO, 400, 10.5, 2.2) + 18
    text(ek, 71, eyebrow_zh, SANS, 400, 11.5, FAINT)
    text(x - 2, 129, title, SERIF, 700, title_size, INK)
    text(x, 168, subtitle, SANS, 400, 13.5, MUTED)
    line(x, rule_y, right, rule_y, BORDER, 1)


def meta_pill(right, y0, y1, parts, fill="#F3F0E8", pad=34, r=16,
              text_dy=None):
    """右上角胶囊：自动量宽，内部用 run() 混排。"""
    pw = sum(tw(p[0], p[1], p[2], p[3]) for p in parts)
    px1 = right
    px0 = px1 - pw - pad
    rrect(px0, y0, px1, y1, fill=fill, r=r)
    dy = (y1 - y0) / 2.0 + 3.5 if text_dy is None else text_dy
    run(px0 + 17, y0 + dy, parts)
    return px0, px1


def caption(y, num, lead, body, right=None, tail=None, x=80):
    """图注：粗体编号 + 粗体引语 + 常规说明（右侧可放 tail）。"""
    cx = x
    text(cx, y, num, SERIF, 700, 13.5, INK)
    cx += tw(num, SERIF, 700, 13.5) + 10
    text(cx, y, lead, SANS, 700, 12.5, BODY)
    cx += tw(lead, SANS, 700, 12.5)
    if body:
        text(cx, y, body, SANS, 400, 12.5, MUTED)
    if tail:
        run(right or 1840, y, tail, anchor="r")


# --------------------------------------------------------------------------
# raster renderer
# --------------------------------------------------------------------------
def render_pil(path, scale=1):
    """按 S 倍绘制再缩到 W*scale x H*scale。scale=2 适合论文/印刷。"""
    img = Image.new("RGB", (int(W * S), int(H * S)), PAGE)
    d = ImageDraw.Draw(img)
    for op in OPS:
        k = op["t"]
        if k == "rrect":
            x0, y0, x1, y1 = [v * S for v in (op["x0"], op["y0"],
                                              op["x1"], op["y1"])]
            d.rounded_rectangle(
                [x0, y0, x1, y1], radius=op["r"] * S, fill=op["fill"],
                outline=op["stroke"],
                width=int(round(op["sw"] * S)) if op["stroke"] else 0)
        elif k == "line":
            d.line([op["x0"] * S, op["y0"] * S, op["x1"] * S, op["y1"] * S],
                   fill=op["color"], width=max(1, int(round(op["w"] * S))))
        elif k == "cubic":
            p0, p1, p2, p3 = op["pts"]
            pts = []
            for i in range(65):
                t = i / 64.0
                a = (1 - t) ** 3
                b = 3 * (1 - t) ** 2 * t
                c = 3 * (1 - t) * t ** 2
                e = t ** 3
                pts.append(((a * p0[0] + b * p1[0] + c * p2[0] + e * p3[0]) * S,
                            (a * p0[1] + b * p1[1] + c * p2[1] + e * p3[1]) * S))
            d.line(pts, fill=op["color"],
                   width=max(1, int(round(op["w"] * S))), joint="curve")
        elif k == "circle":
            cx, cy, r = op["cx"] * S, op["cy"] * S, op["r"] * S
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=op["fill"],
                      outline=op["stroke"],
                      width=int(round(op["sw"] * S)) if op["stroke"] else 0)
        elif k == "text":
            f = font(op["fam"], op["wt"], op["size"])
            sw = int(round(op["halo_w"] * S))
            kw = dict(font=f, fill=op["color"],
                      stroke_width=sw, stroke_fill=op["halo"])
            if op["ls"] == 0:
                anc = {"l": "ls", "m": "ms", "r": "rs"}[op["anchor"]]
                d.text((op["x"] * S, op["y"] * S), op["s"], anchor=anc, **kw)
            else:
                # 逐字绘制以实现字距；必须显式 anchor="ls"，
                # 否则 PIL 默认 "la" 会把文本整体上移一个 ascent。
                ls = op["ls"]
                width = tw(op["s"], op["fam"], op["wt"], op["size"], ls)
                x = op["x"]
                if op["anchor"] == "m":
                    x -= width / 2.0
                elif op["anchor"] == "r":
                    x -= width
                for ch in op["s"]:
                    d.text((x * S, op["y"] * S), ch, anchor="ls", **kw)
                    x += tw(ch, op["fam"], op["wt"], op["size"]) + ls
    img = img.resize((int(W * scale), int(H * scale)), Image.LANCZOS)
    img.save(path)
    return path


def render_pngs(outdir, stem="figure", scales=(1, 2), verbose=True):
    """输出多档位 PNG：<stem>_1x.png / <stem>_2x.png …"""
    os.makedirs(outdir, exist_ok=True)
    out = []
    for sc in scales:
        p = os.path.join(outdir, f"{stem}_{sc}x.png")
        render_pil(p, sc)
        out.append(p)
        if verbose:
            print(f"  png  {p}  ({int(W * sc)}x{int(H * sc)})")
    return out


# --------------------------------------------------------------------------
# svg renderer
# --------------------------------------------------------------------------
SVG_FAM = {
    "serif": "Noto Serif SC, Source Han Serif SC, SimSun, serif",
    "sans": "Noto Sans SC, Microsoft YaHei, sans-serif",
    "mono": "Cascadia Mono, Consolas, monospace",
}
SVG_WT = {400: "400", 500: "500", 600: "600", 700: "700"}


def _esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def render_svg(path):
    out = []
    a = out.append
    a('<?xml version="1.0" encoding="UTF-8"?>')
    a(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
      f'viewBox="0 0 {W} {H}">')
    a(f'<rect width="{W}" height="{H}" fill="{PAGE}"/>')
    for op in OPS:
        k = op["t"]
        if k == "rrect":
            x0, y0 = op["x0"], op["y0"]
            w, h = op["x1"] - x0, op["y1"] - y0
            st = (f' stroke="{op["stroke"]}" stroke-width="{op["sw"]}"'
                  if op["stroke"] else "")
            fl = f' fill="{op["fill"]}"' if op["fill"] else ' fill="none"'
            a(f'<rect x="{x0:.2f}" y="{y0:.2f}" width="{w:.2f}" '
              f'height="{h:.2f}" rx="{op["r"]:.2f}"{fl}{st}/>')
        elif k == "line":
            a(f'<line x1="{op["x0"]:.2f}" y1="{op["y0"]:.2f}" '
              f'x2="{op["x1"]:.2f}" y2="{op["y1"]:.2f}" '
              f'stroke="{op["color"]}" stroke-width="{op["w"]}"/>')
        elif k == "cubic":
            p0, p1, p2, p3 = op["pts"]
            a(f'<path d="M {p0[0]:.2f},{p0[1]:.2f} C {p1[0]:.2f},{p1[1]:.2f} '
              f'{p2[0]:.2f},{p2[1]:.2f} {p3[0]:.2f},{p3[1]:.2f}" fill="none" '
              f'stroke="{op["color"]}" stroke-width="{op["w"]}"/>')
        elif k == "circle":
            st = (f' stroke="{op["stroke"]}" stroke-width="{op["sw"]}"'
                  if op["stroke"] else "")
            fl = f' fill="{op["fill"]}"' if op["fill"] else ' fill="none"'
            a(f'<circle cx="{op["cx"]:.2f}" cy="{op["cy"]:.2f}" '
              f'r="{op["r"]:.2f}"{fl}{st}/>')
        elif k == "text":
            anchor = {"l": "start", "m": "middle", "r": "end"}[op["anchor"]]
            ls = f' letter-spacing="{op["ls"]}"' if op["ls"] else ""
            if op["halo"]:
                halo = (f' stroke="{op["halo"]}" stroke-width="{op["halo_w"]}" '
                        f'stroke-linejoin="round" paint-order="stroke"')
            else:
                halo = ""
            fam = SVG_FAM[op["fam"]]
            wt = SVG_WT[op["wt"]]
            # 等宽串逐字输出：渲染器回退字体时也能保持 PIL 算好的网格。
            # 但带 halo 的文本必须整串输出，否则每个字自带的描边会互相啃噬。
            if (op["fam"] == "mono" and op["ls"] == 0 and not op["halo"]
                    and len(op["s"]) > 1):
                total = tw(op["s"], "mono", op["wt"], op["size"])
                gx = op["x"]
                if op["anchor"] == "m":
                    gx -= total / 2.0
                elif op["anchor"] == "r":
                    gx -= total
                for ch in op["s"]:
                    a(f'<text x="{gx:.2f}" y="{op["y"]:.2f}" '
                      f'font-family="{fam}" font-weight="{wt}" '
                      f'font-size="{op["size"]}" fill="{op["color"]}" '
                      f'text-anchor="start">{_esc(ch)}</text>')
                    gx += tw(ch, "mono", op["wt"], op["size"])
                continue
            a(f'<text x="{op["x"]:.2f}" y="{op["y"]:.2f}" '
              f'font-family="{fam}" font-weight="{wt}" '
              f'font-size="{op["size"]}" fill="{op["color"]}" '
              f'text-anchor="{anchor}"{ls}{halo}>{_esc(op["s"])}</text>')
    a('</svg>')
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    return path


def render_svg_file(path):
    return render_svg(path)


# --------------------------------------------------------------------------
# pdf (via headless Chrome / Edge)
# --------------------------------------------------------------------------
_CHROME_CANDIDATES = [
    os.environ.get("FIGKIT_CHROME", ""),
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "google-chrome", "chromium", "chromium-browser", "microsoft-edge",
]


def find_chrome():
    for c in _CHROME_CANDIDATES:
        if not c:
            continue
        if os.path.sep in c or c.startswith("/"):
            if os.path.exists(c):
                return c
        else:
            p = shutil.which(c)
            if p:
                return p
    return None


def export_pdf(svg_path, pdf_path, verbose=True):
    """把 SVG 包进 @page 尺寸为画布的 HTML，用 headless Chrome 打印成矢量 PDF。

    返回 pdf 路径；找不到浏览器时返回 None（PNG/SVG 仍然可用）。
    """
    chrome = find_chrome()
    if not chrome:
        if verbose:
            print("  pdf  skipped（未找到 Chrome/Edge；可用 FIGKIT_CHROME 指定）")
        return None
    with open(svg_path, "r", encoding="utf-8") as fh:
        svg = fh.read()
    svg = svg.split("?>", 1)[-1].lstrip()
    html = (
        '<!DOCTYPE html><html><head><meta charset="utf-8"><style>'
        f"@page{{size:{W}px {H}px;margin:0}}"
        "html,body{margin:0;padding:0;overflow:hidden}"
        f"svg{{display:block;width:{W}px;height:{H}px}}"
        "</style></head><body>" + svg + "</body></html>")
    tmpdir = tempfile.mkdtemp(prefix="figkit_")
    wrap = os.path.join(tmpdir, "wrap.html")
    with open(wrap, "w", encoding="utf-8") as fh:
        fh.write(html)
    os.makedirs(os.path.dirname(os.path.abspath(pdf_path)), exist_ok=True)
    cmd = [chrome, "--headless=new", "--disable-gpu", "--no-sandbox",
           "--no-pdf-header-footer", f"--print-to-pdf={pdf_path}",
           "file:///" + wrap.replace("\\", "/").lstrip("/")]
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=120)
    except Exception as e:                      # noqa: BLE001
        if verbose:
            print(f"  pdf  failed: {e}")
        return None
    if verbose:
        print(f"  pdf  {pdf_path}")
    return pdf_path
