# -*- coding: utf-8 -*-
"""A4 讲解讲义渲染引擎（阅读讲解技能）。

用法：
    python engine.py content.json --out ./out
    python engine.py content.py   --out ./out        # content.py 里定义 CONTENT = {...}

content 是纯数据（dict / JSON），页面顺序固定：
    封面 → §1 材料档案 → §2 逐段精读（自动分页）→ 逻辑链 → 信息点 → 关键句
    → 四题精讲（每题一页）→ 信号词与易错 → 词汇与练习
缺哪个键就跳过对应页面。版式与配色见 references/deliverable-spec.md。

设计单位：1240 × 1754（A4 150dpi），内部 2× 超采样输出 2480 × 3508，PDF 300dpi。
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import kit as fk  # noqa: E402  渲染原语（来自 corpus-annotation-figure 技能）

# ---------------------------------------------------------------- 版式常量
fk.W, fk.H = 1240, 1754
fk.S = 2.0

SERIF, SANS, MONO = fk.SERIF, fk.SANS, fk.MONO
INK, BODY, MUTED, FAINT = fk.INK, fk.BODY, fk.MUTED, fk.FAINT
FAINT2, RULE, HAIR, CARD = fk.FAINT2, fk.RULE, fk.HAIR, fk.CARD
PAGE = fk.PAGE
FAMS = {"serif": SERIF, "sans": SANS, "mono": MONO}

ML, MR = 78, 78
CW = fk.W - ML - MR
TOP, BOTTOM = 92, 1622

BLUE, AMB, GREEN, PURPLE, TEAL = "#1D4ED8", "#A75C06", "#06704F", "#6D28D9", "#0E7490"
BLUE_BG, AMB_BG = "#DCE8FE", "#FDEFC6"
GREEN_BG, PURPLE_BG, TEAL_BG = "#CFF0E2", "#EBE4FE", "#D3EEF5"
CREAM = "#FBF7EE"

CLOSE_PUNCT = set("，。、；：？！）】」』”’…—·%")
OPEN_PUNCT = set("（【「『“‘")


# ---------------------------------------------------------------- 文本工具
def _ascii_apos(s):
    return s.replace("\u2019", "'") if s else s


def units(s):
    out, buf = [], ""
    for ch in s:
        if ch == " ":
            if buf:
                out.append(buf)
                buf = ""
            out.append(" ")
        elif ord(ch) > 0x2E7F or ch in CLOSE_PUNCT or ch in OPEN_PUNCT:
            if buf:
                out.append(buf)
                buf = ""
            out.append(ch)
        else:
            buf += ch
    if buf:
        out.append(buf)
    return out


def wrap(s, maxw, fam=SANS, wt=400, size=19, ls=0.0):
    """按宽度折行，带简单避头尾（行首不出现收尾标点、行尾不留开引号）。"""
    lines, cur = [], ""
    for u in units(_ascii_apos(s)):
        cand = cur + u
        if fk.tw(cand, fam, wt, size, ls) <= maxw or (cur and u in CLOSE_PUNCT):
            cur = cand
            continue
        carry = ""
        if cur and cur[-1] in OPEN_PUNCT:
            cur, carry = cur[:-1], cur[-1]
        if cur.strip():
            lines.append(cur.rstrip())
        cur = ("" if u == " " else u) if not carry else carry + u
    if cur.strip():
        lines.append(cur.rstrip())
    return lines


def tx(x, y, s, fam=SANS, wt=400, size=19, color=BODY, anchor="l", ls=0.0):
    fk.text(x, y, _ascii_apos(s), fam, wt, size, color, anchor=anchor, ls=ls)


def chip(x, y, label, size=16, fg=INK, bg=CREAM, padx=9, h=26):
    w = fk.tw(label, SANS, 500, size) + padx * 2
    fk.rrect(x, y, x + w, y + h, fill=bg, r=7)
    fk.text(x + padx, y + h * 0.72, label, SANS, 500, size, fg)
    return x + w


def _fonts(spec, fsize):
    """[["sans",400,15], ...] → [(fam, wt, size), ...]"""
    out = []
    for item in spec or []:
        fam, wt, sz = item
        out.append((FAMS.get(fam, SANS), wt, sz or fsize))
    return out


# ---------------------------------------------------------------- 文档对象
class Doc:
    def __init__(self, out_dir, footer_note="阅读讲解讲义"):
        self.out = out_dir
        self.pages_dir = os.path.join(out_dir, "pages")
        os.makedirs(self.pages_dir, exist_ok=True)
        for f in os.listdir(self.pages_dir):
            if f.endswith(".png"):
                os.remove(os.path.join(self.pages_dir, f))
        self.footer_note = footer_note
        self.n = 0
        self._open()

    def _open(self):
        fk.reset()
        self.n += 1
        self.y = TOP

    # -- 页面控制
    def footer(self, C=None):
        note = (C or {}).get("footer", self.footer_note)
        fk.line(ML, 1660, ML + CW, 1660, HAIR, 1)
        tx(ML, 1692, note, SANS, 400, 15.5, FAINT)
        tx(ML + CW, 1692, "第 %d 页" % self.n, SANS, 400, 15.5, FAINT, anchor="r")

    def page_break(self, C=None):
        self.footer(C)
        fk.render_pil(os.path.join(self.pages_dir, "p%02d.png" % self.n), scale=2)
        self._open()

    def finish(self, pdf_name="讲解讲义.pdf"):
        self.footer()
        fk.render_pil(os.path.join(self.pages_dir, "p%02d.png" % self.n), scale=2)
        files = sorted(f for f in os.listdir(self.pages_dir) if f.endswith(".png"))
        imgs = [Image.open(os.path.join(self.pages_dir, f)) for f in files]
        pdf = os.path.join(self.out, pdf_name)
        imgs[0].save(pdf, "PDF", resolution=300, save_all=True, append_images=imgs[1:])
        print("pdf ->", pdf, len(imgs), "pages")
        return pdf

    def ensure(self, h):
        if self.y + h > BOTTOM:
            self.page_break()

    def gap(self, h=14):
        self.y += h

    # -- 标题
    def h1(self, num, title, en="", accent=INK):
        self.ensure(110)
        self.y += 22
        fk.rrect(ML, self.y - 4, ML + 5, self.y + 26, fill=accent, r=2)
        tx(ML + 16, self.y + 21, num, MONO, 700, 17, accent)
        x = ML + 16 + fk.tw(num, MONO, 700, 17) + 12
        tx(x, self.y + 23, title, SERIF, 700, 30, INK)
        if en:
            tx(ML + CW, self.y + 21, en, SANS, 400, 15, FAINT2, anchor="r", ls=1.4)
        self.y += 50
        fk.line(ML, self.y - 14, ML + CW, self.y - 14, RULE, 1)

    def h2(self, title, accent=INK, en=""):
        self.ensure(80)
        self.y += 12
        tx(ML, self.y + 18, title, SANS, 700, 23, accent)
        if en:
            tx(ML + CW, self.y + 17, en, MONO, 400, 15, FAINT2, anchor="r")
        self.y += 34

    # -- 正文块
    def para(self, s, size=19, lh=30, color=BODY, fam=SANS, wt=400,
             indent=0, gap=12, maxw=None):
        for ln in wrap(s, (maxw or CW) - indent, fam, wt, size):
            self.ensure(lh)
            tx(ML + indent, self.y + size * 0.86, ln, fam, wt, size, color)
            self.y += lh
        self.y += gap

    def lead_para(self, label, s, color, size=16.6, lh=27, gap=10):
        lw = fk.tw(label, SANS, 700, size)
        lines = wrap(s, CW - lw - 14, SANS, 400, size)
        if not lines:
            return
        self.ensure(lh)
        tx(ML, self.y + size * 0.86, label, SANS, 700, size, color)
        tx(ML + lw + 14, self.y + size * 0.86, lines[0], SANS, 400, size, BODY)
        self.y += lh
        for ln in lines[1:]:
            self.ensure(lh)
            tx(ML, self.y + size * 0.86, ln, SANS, 400, size, BODY)
            self.y += lh
        self.y += gap

    def bullets(self, items, size=18.6, lh=29, gap=8, accent=INK):
        for it in items:
            lead, body = it if isinstance(it, (tuple, list)) else ("", it)
            x0, maxw = ML + 18, CW - 18
            if self.y + lh > BOTTOM:
                self.page_break()
            fk.rrect(ML + 2, self.y + size * 0.52, ML + 9, self.y + size * 0.52 + 7,
                     fill=accent, r=2)
            if lead:
                lw = fk.tw(lead, SANS, 700, size)
                tx(x0, self.y + size * 0.86, lead, SANS, 700, size, INK)
                rest = wrap(body, maxw - lw - 7, SANS, 400, size)
                if rest:
                    tx(x0 + lw + 7, self.y + size * 0.86, rest[0], SANS, 400, size, BODY)
            else:
                rest = wrap(body, maxw, SANS, 400, size)
                if rest:
                    tx(x0, self.y + size * 0.86, rest[0], SANS, 400, size, BODY)
            self.y += lh
            for ln in rest[1:]:
                self.ensure(lh)
                tx(x0, self.y + size * 0.86, ln, SANS, 400, size, BODY)
                self.y += lh
            self.y += gap

    def quote(self, s, size=18.6, accent=BLUE, label="原文", gap=10):
        lines = wrap(s, CW - 46, SERIF, 400, size)
        h = 26 + 22 + len(lines) * (size + 9) + 14
        self.ensure(h)
        fk.rrect(ML, self.y, ML + CW, self.y + h, fill="#FBF9F3", r=9)
        fk.rrect(ML, self.y, ML + 4, self.y + h, fill=accent, r=2)
        tx(ML + 18, self.y + 24, label, SANS, 700, 14, accent, ls=1.2)
        yy = self.y + 50
        for ln in lines:
            tx(ML + 18, yy, ln, SERIF, 400, size, "#243141")
            yy += size + 9
        self.y += h + gap

    def callout(self, lead, body, accent=GREEN, fill="#F4FAF6", gap=12, size=18.4):
        lines = wrap(body, CW - 40, SANS, 400, size)
        h = 30 + 24 + len(lines) * (size + 8) + 12
        self.ensure(h)
        fk.rrect(ML, self.y, ML + CW, self.y + h, fill=fill, r=9)
        fk.rrect(ML, self.y, ML + 4, self.y + h, fill=accent, r=2)
        tx(ML + 18, self.y + 30, lead, SANS, 700, size, accent)
        yy = self.y + 56
        for ln in lines:
            tx(ML + 18, yy, ln, SANS, 400, size, BODY)
            yy += size + 8
        self.y += h + gap

    def table(self, spec):
        headers = spec["headers"]
        rows = spec["rows"]
        widths = spec.get("widths") or [1] * len(headers)
        fsize = spec.get("fsize", 17.2)
        lh = spec.get("lh", 26)
        pad = spec.get("pad", 9)
        aligns = spec.get("aligns") or ["l"] * len(headers)
        fonts = _fonts(spec.get("fonts"), fsize) or [(SANS, 400, fsize)] * len(headers)
        header_fill = spec.get("header_fill", "#2B3648")
        header_fg = spec.get("header_fg", "#FFFFFF")
        header_fsize = spec.get("header_fsize") or (fsize - 0.6)
        colors = {tuple(k): v for k, v in (spec.get("colors") or {}).items()}
        row_fills = spec.get("row_fills")
        bars = spec.get("bars")

        fw = sum(widths)
        ws = [w / fw * CW for w in widths]

        def draw_header():
            hh = lh + pad * 2
            fk.rrect(ML, self.y, ML + CW, self.y + hh, fill=header_fill, r=6)
            x = ML + pad
            for i, hd in enumerate(headers):
                if aligns[i] == "r":
                    tx(x + ws[i] - pad * 2, self.y + pad + lh * 0.74, hd,
                       SANS, 700, header_fsize, header_fg, anchor="r")
                else:
                    tx(x, self.y + pad + lh * 0.74, hd, SANS, 700, header_fsize, header_fg)
                x += ws[i]
            self.y += hh + 4

        draw_header()
        for ri, row in enumerate(rows):
            cells = []
            for i, c in enumerate(row):
                fam, wt, sz = fonts[i]
                cells.append(wrap(str(c), ws[i] - pad * 2, fam, wt, sz))
            nlines = max(1, max(len(c) for c in cells))
            rh = nlines * lh + pad * 2
            if self.y + rh > BOTTOM:
                self.page_break()
                draw_header()
            fill = CARD if ri % 2 == 0 else "#F7F4EC"
            if row_fills:
                fill = row_fills[ri % len(row_fills)] or fill
            fk.rrect(ML, self.y, ML + CW, self.y + rh, fill=fill, r=5)
            if bars:
                bc = bars[ri % len(bars)]
                if bc:
                    fk.rrect(ML, self.y, ML + 4, self.y + rh, fill=bc, r=2)
            x = ML + pad
            for i, ls in enumerate(cells):
                fam, wt, sz = fonts[i]
                yy = self.y + pad + lh * 0.74
                cc = colors.get((ri, i), BODY)
                for ln in ls:
                    if aligns[i] == "r":
                        tx(x + ws[i] - pad * 2, yy, ln, fam, wt, sz, cc, anchor="r")
                    else:
                        tx(x, yy, ln, fam, wt, sz, cc)
                    yy += lh
                x += ws[i]
            fk.line(ML, self.y + rh, ML + CW, self.y + rh, HAIR, 1)
            self.y += rh
        self.y += 14

    def steps(self, items):
        for i, (num, title, body, color) in enumerate(items):
            lines = wrap(body, CW - 160, SANS, 400, 17.6)
            hh = max(62, len(lines) * 26 + 28)
            self.ensure(hh + 28)
            fk.rrect(ML, self.y, ML + CW, self.y + hh, fill=CARD,
                     stroke=fk.BORDER, sw=1, r=9)
            fk.circle(ML + 32, self.y + hh / 2, 15, fill=color)
            tx(ML + 32, self.y + hh / 2 + 6, num, SANS, 700, 15, "#FFFFFF", anchor="m")
            tx(ML + 58, self.y + 24, title, SANS, 700, 19, color)
            yy = self.y + 49
            for ln in lines:
                tx(ML + 58, yy, ln, SANS, 400, 17.6, BODY)
                yy += 26
            self.y += hh
            if i < len(items) - 1:
                fk.line(ML + 32, self.y + 3, ML + 32, self.y + 15, fk.BORDER, 2)
                fk.line(ML + 26, self.y + 9, ML + 32, self.y + 17, fk.BORDER, 2)
                fk.line(ML + 38, self.y + 9, ML + 32, self.y + 17, fk.BORDER, 2)
                self.y += 24


# ---------------------------------------------------------------- 段落块
def para_height(d, p):
    q_lines = wrap(p["en"], CW - 46, SERIF, 400, 18.6)
    q = 26 + 22 + len(q_lines) * 27.6 + 14 + 10
    lead_lw = fk.tw("段意", SANS, 700, 16.6)
    lead_lines = max(1, len(wrap(p["summary"], CW - lead_lw - 14, SANS, 400, 16.6)))
    lead = lead_lines * 27 + 10
    bl = 0
    for it in p.get("notes", []):
        leadtxt, bodytxt = it if isinstance(it, (tuple, list)) else ("", it)
        lw = fk.tw(leadtxt, SANS, 700, 18.6) if leadtxt else 0
        n = len(wrap(bodytxt, CW - 18 - lw - 7, SANS, 400, 18.6))
        bl += n * 29 + 8
    return 40 + q + lead + bl


def para_block(d, p):
    d.gap(4)
    col = p.get("color", BLUE)
    x = chip(ML, d.y - 4, p["id"], size=15.5, fg=col, bg=p.get("bg", BLUE_BG)) + 8
    chip(x, d.y - 4, p["fn"], size=15.5, fg=col, bg=p.get("bg", BLUE_BG))
    d.y += 36
    d.quote(p["en"], accent=col)
    d.lead_para("段意", p["summary"], col)
    d.bullets(p.get("notes", []), accent=col)


# ---------------------------------------------------------------- 页面
def page_cover(d, C):
    fk.line(ML, 120, ML + CW, 120, RULE, 1)
    tx(ML, 168, C.get("eyebrow", "阅读讲解讲义 · READING HANDOUT"), SANS, 500, 14.5,
       FAINT, ls=2.2)
    tx(ML, 258, C["title"], SERIF, 700, 52, INK)
    if C.get("subtitle"):
        tx(ML, 316, C["subtitle"], SERIF, 400, 26, BLUE)
    if C.get("desc"):
        tx(ML, 366, C["desc"], SANS, 400, 17.5, MUTED)

    meta = C.get("meta") or []
    y = 424
    for i, (k, v) in enumerate(meta[:4]):
        x = ML + (500 if i % 2 else 0)
        yy = y + (74 if i >= 2 else 0)
        tx(x, yy, k, SANS, 700, 13.5, FAINT2, ls=1.4)
        tx(x, yy + 26, v, SANS, 400, 16.5, BODY)

    y = 590
    cards = C.get("answer_cards") or []
    if cards:
        tx(ML, y, C.get("answer_cards_title", "答案速览 · 一句话理由"), SANS, 700, 15, INK)
        y += 18
        cw = (CW - (len(cards) - 1) * 14) / len(cards)
        for i, (no, ans, why, col) in enumerate(cards):
            x = ML + i * (cw + 14)
            fk.rrect(x, y, x + cw, y + 182, fill=CARD, stroke=fk.BORDER, sw=1, r=10)
            fk.rrect(x, y, x + cw, y + 5, fill=col, r=2)
            tx(x + 16, y + 34, no, MONO, 700, 15, col)
            tx(x + 16, y + 82, ans, SERIF, 700, 40, INK)
            yy = y + 112
            for ln in wrap(why, cw - 32, SANS, 400, 13.4):
                tx(x + 16, yy, ln, SANS, 400, 13.4, MUTED)
                yy += 21

    y = 820
    steps = C.get("method_steps") or []
    if steps:
        fk.rrect(ML, y, ML + CW, y + 96, fill=CREAM, r=10)
        tx(ML + 18, y + 30, C.get("method_title", "四步法"), SANS, 700, 15.5, INK)
        x = ML + 108
        for i, s in enumerate(steps):
            tx(x, y + 30, s, SANS, 500, 16, BODY)
            x += fk.tw(s, SANS, 500, 16) + 30
            if i < len(steps) - 1:
                tx(x - 22, y + 30, "›", SANS, 700, 17, FAINT2)
        if C.get("method_note"):
            tx(ML + 18, y + 66, C["method_note"], SANS, 400, 14.6, MUTED)

    y = 966
    usage = C.get("usage") or []
    if usage:
        tx(ML, y, C.get("usage_title", "本讲义怎么用"), SANS, 700, 15, INK)
        y += 26
        for k, v in usage:
            fk.circle(ML + 5, y + 6, 3.6, fill=BLUE)
            tx(ML + 18, y + 13, k, SANS, 700, 15, INK)
            tx(ML + 152, y + 13, v, SANS, 400, 15, BODY)
            y += 28

    y = 1246
    one = C.get("oneline")
    if one:
        label, text, note = one
        fk.rrect(ML, y, ML + CW, y + 150, fill="#F2F6FF", r=10)
        tx(ML + 20, y + 34, label, SANS, 700, 14, BLUE, ls=1.2)
        tx(ML + 20, y + 78, text, SERIF, 500, 26, INK)
        tx(ML + 20, y + 116, note, SANS, 400, 15.4, MUTED)

    fk.line(ML, 1430, ML + CW, 1430, HAIR, 1)
    tx(ML, 1462, C.get("files_label", "配套文件"), SANS, 700, 13.5, FAINT2, ls=1.4)
    tx(ML, 1492, C.get("files_note", ""), SANS, 400, 15, MUTED)


def page_packet(d, C):
    P = C["packet"]
    acc = P.get("accent", BLUE)
    d.h1(P["num"], P["title"], P.get("en", ""), accent=acc)
    if P.get("intro"):
        d.para(P["intro"], gap=14)
    d.table(P["meta_table"])
    if P.get("order_title"):
        d.h2(P["order_title"], P.get("order_accent", acc))
    d.table(P["order_table"])
    if P.get("callout"):
        lead, body = P["callout"]
        d.callout(lead, body, accent=P.get("callout_accent", acc),
                  fill=P.get("callout_fill", "#F2F6FF"))
    S = C.get("paras_section")
    if S:
        d.h1(S["num"], S["title"], S.get("en", ""), accent=S.get("accent", GREEN))
        if S.get("note"):
            d.para(S["note"], gap=10)
    if C.get("paras") and P.get("include_first_para", True):
        para_block(d, C["paras"][0])
    if P.get("after_callout"):
        lead, body = P["after_callout"]
        d.callout(lead, body, accent=P.get("after_callout_accent", P.get("accent", BLUE)),
                  fill=P.get("after_callout_fill", "#F2F6FF"))


def page_paras(d, C, idxs):
    for i in idxs:
        para_block(d, C["paras"][i])
        d.gap(14)


def page_chain(d, C):
    K = C["chain"]
    acc = K.get("accent", AMB)
    d.h1(K["num"], K["title"], K.get("en", ""), accent=acc)
    if K.get("intro"):
        d.para(K["intro"], gap=14)
    d.steps([tuple(x) for x in K["steps"]])
    d.gap(6)
    if K.get("basis_title"):
        d.h2(K["basis_title"], acc)
    d.table(K["basis_table"])
    if K.get("callout"):
        lead, body = K["callout"]
        d.callout(lead, body, accent=acc, fill=K.get("callout_fill", "#FFF9EE"))
    if K.get("transfer"):
        if K.get("transfer_title"):
            d.h2(K["transfer_title"], acc)
        d.bullets(K["transfer"], accent=acc)


def page_infos(d, C):
    I = C["infos"]
    acc = I.get("accent", TEAL)
    d.h1(I["num"], I["title"], I.get("en", ""), accent=acc)
    if I.get("intro"):
        d.para(I["intro"], gap=12)
    d.table(I["table"])
    if I.get("usage_callout"):
        lead, body = I["usage_callout"]
        d.callout(lead, body, accent=acc, fill=I.get("fill", "#F0FAFC"))
    if I.get("direction"):
        if I.get("direction_title"):
            d.h2(I["direction_title"], acc)
        d.bullets(I["direction"], accent=acc)
    if I.get("recap_callout"):
        lead, body = I["recap_callout"]
        d.callout(lead, body, accent=acc, fill=I.get("fill", "#F0FAFC"))


def page_key(d, C):
    K = C["key"]
    acc = K.get("accent", PURPLE)
    d.h1(K["num"], K["title"], K.get("en", ""), accent=acc)
    if K.get("intro"):
        d.para(K["intro"], gap=12)
    d.quote(K["sentence"], accent=acc, label=K.get("sentence_label", "依据句"))
    d.table(K["roles_table"])
    if K.get("why_bullets"):
        if K.get("why_title"):
            d.h2(K["why_title"], acc)
        d.bullets(K["why_bullets"], accent=acc)
    if K.get("transfer"):
        if K.get("transfer_title"):
            d.h2(K["transfer_title"], acc)
        d.bullets(K["transfer"], accent=acc)
    if K.get("recap"):
        lead, body = K["recap"]
        d.callout(lead, body, accent=acc, fill=K.get("fill", "#F8F4FE"))
    if K.get("grammar_bullets"):
        if K.get("grammar_title"):
            d.h2(K["grammar_title"], acc)
        d.bullets(K["grammar_bullets"], accent=acc)
    if K.get("practice"):
        lead, body = K["practice"]
        d.callout(lead, body, accent=acc, fill=K.get("fill", "#F8F4FE"))


def page_question(d, C, q):
    acc = q.get("accent", BLUE)
    sec = C.get("q_section", {})
    d.h1(sec.get("num", "06"), sec.get("title_prefix", "精讲 · ") + q["no"],
         sec.get("en_prefix", "QUESTION ") + q["no"].lstrip("Q"), accent=acc)
    tx(ML, d.y + 8, "题干", SANS, 700, 13, FAINT2, ls=1.4)
    d.y += 24
    for ln in wrap(q["q"], CW, SERIF, 500, 20):
        tx(ML, d.y + 16, ln, SERIF, 500, 20, INK)
        d.y += 30
    d.y += 4
    x = ML
    for k in q.get("keys", []):
        x = chip(x, d.y, k, size=15, fg=acc, bg="#FFFFFF") + 8
    d.y += 36
    tx(ML, d.y + 12, "定位", SANS, 700, 13, FAINT2, ls=1.4)
    tx(ML + 58, d.y + 12, q.get("loc", ""), SANS, 500, 15.2, acc)
    d.y += 26
    d.quote(q["src"], accent=acc, label=q.get("src_label", "证据句"))
    if q.get("rep"):
        d.h2(q.get("rep_title", "同义替换：选项是怎么从原文改出来的"), acc)
        d.table({"headers": q.get("rep_head", ["原文", "选项 ／ 对应", "说明"]),
                 "rows": q["rep"], "widths": q.get("rep_widths", [42, 30, 28]),
                 "fonts": q.get("rep_fonts", [["sans", 400, 13.8], ["sans", 400, 14.4],
                                              ["sans", 400, 15.2]]),
                 "aligns": ["l", "l", "l"], "lh": 27})
    if q.get("opts"):
        d.h2("选项判定", acc)
        opt_rows = [[mark, opt, kind, why] for opt, mark, kind, why in q["opts"]]
        colors = {(i, 0): ("#0B7A4B" if r[0] == "√" else "#B42318")
                  for i, r in enumerate(opt_rows)}
        d.table({"headers": ["判", "选项", "干扰类型", "判断理由"], "rows": opt_rows,
                 "widths": [6, 34, 18, 44],
                 "fonts": [["sans", 700, 16.4], ["sans", 400, 15.0],
                           ["sans", 500, 14.0], ["sans", 400, 15.0]],
                 "aligns": ["m", "l", "l", "l"], "lh": 27, "colors": colors})
    if q.get("walk"):
        d.h2(q.get("walk_title", "解题实录：这题我是这么走过来的"), acc)
        d.bullets(q["walk"], accent=acc)
    if q.get("tips"):
        d.h2(q.get("tips_title", "这题可迁移的做法"), acc)
        d.bullets(q["tips"], accent=acc)
    if q.get("ext"):
        d.h2(q.get("ext_title", "同类变式怎么变"), acc)
        d.bullets(q["ext"], accent=acc)
    if q.get("recap"):
        d.callout(q.get("recap_title", "一句话复盘"), q["recap"], accent=acc,
                  fill="#FBF9F3")


def page_signals(d, C):
    S = C["signals"]
    acc = S.get("accent", GREEN)
    d.h1(S["num"], S["title"], S.get("en", ""), accent=acc)
    if S.get("intro"):
        d.para(S["intro"], gap=12)
    d.table(S["signals_table"])
    if S.get("verbs_table"):
        if S.get("verbs_title"):
            d.h2(S["verbs_title"], acc)
        d.table(S["verbs_table"])
    if S.get("selfcheck_table"):
        if S.get("selfcheck_title"):
            d.h2(S["selfcheck_title"], acc)
        d.table(S["selfcheck_table"])
    if S.get("callout"):
        lead, body = S["callout"]
        d.callout(lead, body, accent=acc, fill=S.get("fill", "#F3FAF6"))


def page_vocab(d, C):
    V = C["vocab"]
    acc = V.get("accent", BLUE)
    d.h1(V["num"], V["title"], V.get("en", ""), accent=acc)
    d.table(V["table"])
    if V.get("practice"):
        d.h2(V.get("practice_title", "练习建议"), acc)
        d.bullets(V["practice"], accent=acc)
    if V.get("self_test"):
        d.h2(V.get("self_test_title", "脱稿自测"), acc)
        d.bullets(V["self_test"], accent=acc)
    if V.get("files_callout"):
        lead, body = V["files_callout"]
        d.callout(lead, body, accent=acc, fill="#F2F6FF")


# ---------------------------------------------------------------- 主流程
def load_content(path):
    if path.endswith(".json"):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    spec = importlib.util.spec_from_file_location("content_mod", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.CONTENT


def _para_groups(C, start=0):
    pages = C.get("para_pages")
    if pages:
        return [list(pg) for pg in pages]
    # 自动分页：按高度估算，每页尽量填满
    groups, cur = [], []
    probe = Doc.__new__(Doc)
    paras = C["paras"]
    for i in range(start, len(paras)):
        p = paras[i]
        h = para_height(probe, p) + 18
        used = sum(para_height(probe, paras[j]) + 18 for j in cur)
        if cur and used + h > (BOTTOM - TOP - 40):
            groups.append(cur)
            cur = [i]
        else:
            cur.append(i)
    if cur:
        groups.append(cur)
    return groups


def render(C, out_dir, pdf_name=None):
    os.makedirs(out_dir, exist_ok=True)
    d = Doc(out_dir, footer_note=C.get("footer", "阅读讲解讲义"))
    page_cover(d, C)
    if "packet" in C:
        d.page_break(C)
        page_packet(d, C)
    if C.get("paras"):
        start = 1 if ("packet" in C and C["packet"].get("include_first_para", True)) else 0
        groups = _para_groups(C, start)
        if start == 0:
            S = C.get("paras_section")
            if S:
                d.h1(S["num"], S["title"], S.get("en", ""), accent=S.get("accent", GREEN))
                if S.get("note"):
                    d.para(S["note"], gap=10)
            page_paras(d, C, groups[0])
            groups = groups[1:]
        for g in groups:
            d.page_break(C)
            page_paras(d, C, g)
    for key, fn in (("chain", page_chain), ("infos", page_infos), ("key", page_key)):
        if key in C:
            d.page_break(C)
            fn(d, C)
    for q in C.get("questions", []):
        d.page_break(C)
        page_question(d, C, q)
    for key, fn in (("signals", page_signals), ("vocab", page_vocab)):
        if key in C:
            d.page_break(C)
            fn(d, C)
    return d.finish(pdf_name or C.get("pdf_name", "讲解讲义.pdf"))


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__)
        return 1
    path = argv[0]
    out = "out"
    pdf_name = None
    i = 1
    while i < len(argv):
        if argv[i] == "--out":
            out = argv[i + 1]
            i += 2
        elif argv[i] == "--pdf-name":
            pdf_name = argv[i + 1]
            i += 2
        else:
            i += 1
    C = load_content(path)
    render(C, out, pdf_name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
