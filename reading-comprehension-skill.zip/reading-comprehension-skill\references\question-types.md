# 题型库 · 干扰项类型库 · 解题实录 · 变式

## 1. 八类题型与固定动作

| 题型 | 题干标志 | 固定动作 | 答案特征 |
|---|---|---|---|
| 细节·事实 | `What do we know about …?` / `According to the passage, …` | 关键词首现处定位 → 逐词替换 | 原文某句的改写，范围与原文一致 |
| 细节·方式/关系 | `How does A contribute to B?` / `How …?` | 找关系动词（`rely on` / `link A to B` / `lead to`）→ 确认两个主体 | 保留「谁对谁、什么方向」 |
| 词义猜测 | `What does the word "X" probably mean?` | 并列/对比结构定褒贬 + 词根 + 代入检验 | 与上下文语气一致、与并列项同类 |
| 句意理解 | `What does the underlined sentence suggest?` | 拆句（主谓宾 + 修饰）+ 结合上下文 | 不照抄原句词，概括其含义 |
| 推断 | `What can we infer / learn …?` | 原文事实 + 一步合理推进 | 能由原文推出，但不等于原文原句 |
| 主旨/意图 | `mainly about` / `mainly appeal for` / `purpose` | 段末呼吁句 + 冒号列举 + 首尾呼应 | 覆盖全文，不偏一段、不过窄 |
| 态度/评价 | `attitude` / `tone` / `think of` | 评价词（`sad` / `worrying` / `promising`） | 与评价词同类（正/负/中立） |
| 正误判断 | `Which is true / NOT true?` | 逐项回原文核对，先划掉明显错项 | 三个错项都能命名错因 |

## 2. 干扰项类型库（排除时直接报类型名）

| 类型 | 怎么设错 | 识别口诀 | 例子 |
|---|---|---|---|
| 因果错位 | 把「位置/方式/伴随」说成「成因」 | 「问的是 why 还是 where？」 | 原文「洋流在此交汇」→ 选项「由洋流形成」 |
| 对象错位 | 把受害/主体换成另一个名词 | 「这个动作的宾语是谁？」 | 原文「塑料伤害 marine life」→ 选项「塑料影响 garbage patches」 |
| 主体错位 | 把 A 的行为安到 B 身上 | 「主语是谁？」 | 幼鱼依附 Porpita → 选项说 neuston 依附 |
| 认知状态反了 | `known` / `believed` 与 `thought` / `found` 混用 | 「是旧说还是新发现？」 | 原文 `were long thought lifeless` → 选项 `were known to support diverse ecosystems` |
| 时态错位 | 把「过去被以为」说成「现在已知」 | 「was / were / is？」 | `once considered` 对 `were long thought`（对）vs `is known`（错） |
| 拼凑后文 | 偷用后文出现的名词 | 「这个词在本句出现过吗？」 | 用 P3 的 `digestive` / `habitat` 造选项 |
| 方向反转 | 把「导致」说成「帮助」，把「分离应激」说成「打破关系」 | 「动词朝哪边？」 | `plastics block digestive systems` → 选项 `help digest plastics` |
| 绝对化 | `all` / `never` / `only` / `must` / `completely` | 「原文有这么绝对吗？」 | `reduce plastic use` → 选项 `stop all plastic production` |
| 以偏概全 | 只说三方中的一方 | 「原文列了几项？」 | `businesses / governments / individuals` → 选项 `only businesses` |
| 过度推断 | 把「建议」升级为「责任/禁令」 | 「原文说的是 should 还是 must？」 | `take full responsibility` |
| 反向诱导 | 用的正是原文里被质疑的做法 | 「这个做法作者支持还是反思？」 | 原文 `rethinking cleanup` → 选项 `use technology to clean up` |
| 无关项 | 词面像但语义无关 | 「这句和题干问的是同一件事吗？」 | `Clean` 与 `entangle` 无关 |
| 范围扩大 | `the largest one` → `all patches` | 「限定词还在吗？」 | `in the largest one` → 选项泛指全部 |
| 程度失当 | `major` → `the most important` | 「原文是 major 还是 only？」 | — |
| 张冠李戴（引语） | 把专家观点安到作者/别人头上 | 「谁说的？」 | — |

## 3. 解题实录模板（每题 4 步，第一人称）

```
· 读题干：<关键词> → 问<什么类型>；<有无段落提示>
· 扫原文：<关键词首现处 / 指定段落> → 从<第几段>读起
· 读定位句：圈<信号词1>（旧/因）、<信号词2>（转/果）
· 对选项：<A 错因>、<B 错因>、<C 错因> → 只剩<答案>
```

写实录取三条硬要求：
1. **写清起点**：为什么从这一段/这一句开始（首现、段落提示、题文同序）。
2. **写清动作**：圈了哪些词、划了哪句。
3. **写清排除**：每个错项一句，**必须带类型名**。

## 4. 变式生成（每题至少 2 条）

| 变式方向 | 做法 | 例子 |
|---|---|---|
| 换问法 | 同一句原文换题干动词（问事实 → 问原因 → 问作用） | `What do we know about X?` → `What did researchers find in X?` |
| 换主体 | 把题干主体换成同句的另一个名词 | patches → `the largest patch`；neuston → `Porpita` |
| 换错项 | 把正确答案之外的一个错项改造成新错项 | `known` → `have always been known`（加 `always` 双重错） |
| 升题型 | 细节题升级为主旨/推断题 | 由 `rely on neuston` 升到 `Why are neuston important to the wider ecosystem?` |
| 反向命题 | 用原文被质疑的做法当选项 | 由 `rethinking cleanup` 出「作者对大规模清理的态度」 |

## 5. 选项判定表的写法（讲义字段）

```json
{"opt": "A. formed by natural currents and waves", "ok": false,
 "type": "因果错位", "why": "currents/waves 说的是位置与移动；成因首句已给：human-generated garbage"}
```

- `ok: true` → 讲义画绿色 `√`，`type` 写 `——`；
- `ok: false` → 红色 `×`，`type` 必须是上表 15 类之一（可写「类型+补充」）；
- `why` 一句话，先判断后依据，尽量避免超过 40 个汉字。
