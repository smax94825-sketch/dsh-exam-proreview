# 信号词 · 题干动词 · 陷阱词 · 态度词

## 1. 原文信号词（读到就要动手标记）

### 新旧认知（几乎必跟反转，必考）
`were long thought` · `was long believed` · `used to be considered` · `it was once assumed` ·
`for a long time` · `conventional wisdom` · `people used to think` · `was said to be`

### 转折 / 让步（答案分界线）
`but` · `however` · `yet` · `although` · `though` · `while` · `in fact` · `actually` ·
`instead` · `rather than` · `on the contrary` · `surprisingly` · `even so`

### 因果
`because` · `since` · `as a result` · `lead to` · `result in` · `cause` · `give rise to` ·
`account for` · `owing to` · `due to` · `so that` · `therefore` · `thus`

### 递进 / 并列（词义题与细节题的锚）
`not only … but also` · `not merely … but` · `both … and` · `either … or` · `neither … nor` ·
`moreover` · `furthermore` · `in addition` · `beyond this` · `what’s more` · `as well as`

### 举例 / 具体化（例证句考细节）
`for example` · `for instance` · `such as` · `like` · `including` · `take … as an example`

### 供给 / 关系（细节题、关系题）
`rely on` · `depend on` · `feed on` · `prey on` · `a major food source` · `link A to B` ·
`connect A with B` · `be associated with` · `be related to` · `interact with`

### 程度 / 范围（防「范围扩大」类错项）
`in the largest one` · `among` · `most` · `major` · `mainly` · `partly` · `to some extent` ·
`at least` · `up to` · `nearly` · `about`

### 呼吁 / 主张（主旨题落点）
`urges` · `calls for` · `appeals to` · `demands` · `requires` · `should` · `must` ·
`it’s time to` · `we need to` · `the key is` · `only by … can we`

### 结论 / 总结
`in short` · `in conclusion` · `to sum up` · `overall` · `ultimately` · `above all` ·
`the point is` · `what matters is`

### 自我修正 / 态度转变
`realizing …` · `she has begun to` · `no longer` · `rethinking` · `reconsider` ·
`it turns out` · `it is not that … but that`

## 2. 题干动词解码（先看它问什么）

| 题干动词 / 问法 | 题型 | 动作 |
|---|---|---|
| `know` / `according to the passage` | 细节判断 | 回原文定位，逐词核对 |
| `contribute to` / `lead to` / `affect` | 关系/方式 | 找关系动词 + 两个主体 |
| `probably mean` / `closest in meaning` | 词义猜测 | 并列结构 + 词根 + 语气 |
| `suggest` / `infer` / `imply` | 推断 | 原文事实往前推一步，不选原句 |
| `mainly about` / `mainly appeal for` | 主旨/意图 | 段末呼吁 + 冒号列举 |
| `purpose` / `in order to` | 写作目的 | 看文体与结构（问题—证据—对策） |
| `attitude` / `tone` / `think of` | 态度 | 评价词定褒贬 |
| `best title` | 标题 | 覆盖全文，不偏一段、不过窄 |
| `true` / `NOT true` / `EXCEPT` | 正误判断 | 逐项回原文，注意 NOT |
| `why` | 原因 | 找 `because` / `for` / 分词短语表原因 |
| `how` | 方式 | 找 `by` / `through` / 动词方式 |
| `what can be learned` | 推断 | 同 `infer` |

## 3. 选项陷阱词（见到先怀疑）

`all` · `never` · `only` · `must` · `always` · `completely` · `entirely` · `nothing` ·
`everyone` · `no one` · `impossible` · `the most` · `first` · `prove` · `guarantee`

> 出现这些词不等于错，但必须回原文确认程度与范围是否一致；原文是 `reduce` 就不能选 `stop`。

## 4. 态度词（正 / 负 / 中立）

| 负向 | 正向 | 中立/客观 |
|---|---|---|
| sad · worrying · harmful · damaging · threaten · destroy · delicate（脆弱） · concern · criticize · doubt · question · rethink（质疑式） | promising · beneficial · effective · encouraging · hopeful · support · praise · appreciate · worth trying | report · note · find · describe · observe · suggest（中性陈述） |

判断口诀：**全段负向词占多数 → 词义题的答案不会选褒义词。**

## 5. 逻辑关系连词（写逻辑链时当「依据词」用）

- 顺承：`and` · `then` · `besides` · `also`
- 转折：`but` · `yet` · `however` · `nevertheless`
- 因果：`because` · `so` · `therefore` · `thus` · `hence`
- 条件：`if` · `unless` · `as long as` · `provided that`
- 让步：`although` · `even though` · `while` · `despite` · `in spite of`
- 目的：`to` · `in order to` · `so as to` · `for the purpose of`
- 对比：`while` · `whereas` · `in contrast` · `on the other hand`
