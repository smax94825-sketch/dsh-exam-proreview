# 讲义版式规格 · content schema · 排障

## 1. 成图规格

| 项 | 值 |
|---|---|
| 版面 | A4 纵向，设计单位 1240 × 1754（A4 @150dpi） |
| 输出位图 | 2× 超采样 → 2480 × 3508 px |
| PDF | 由 2× PNG 合成，`resolution=300`（A4），单页约 0.5 MB |
| 边距 | 左右 78，正文宽 1084；上 92；下 1622 |
| 底色 | 米白 `#FBFAF6` |
| 字体 | 自动探测：serif→Noto Serif SC / 宋体；sans→Noto Sans SC / 微软雅黑 / 黑体；mono→Cascadia Mono / Consolas |
| 配色 | 墨黑 `#1C1C1C`、正文 `#333`、淡色 `#8A8578`；段落色 P1 蓝 `#1D4ED8`、P2 绿 `#06704F`、P3 琥珀 `#A75C06`、P4 紫 `#6D28D9`、信息点青 `#0E7490` |
| 判定色 | √ 绿 `#0B7A4B`、× 红 `#B42318` |

> 字体缺中文会渲染成豆腐块 `□`。含中文的表格列一律用 `sans`，`mono` 只放纯英文/数字。

## 2. 页面顺序（缺键即跳过该页）

1. **封面**（`title/subtitle/desc/meta/answer_cards/method_steps/usage/oneline/files_note`）
2. **§1 材料档案**（`packet`）+ **§2 逐段精读**开头（含 `paras[0]`，可关）
3. **§2 续**：其余段落自动分页（`paras` + `paras_section`）
4. **§3 逻辑链**（`chain`）
5. **§4 信息点清单**（`infos`）
6. **§5 关键句拆解**（`key`）
7. **§6 逐题精讲**（`q_section` + `questions`，每题一页）
8. **§7 信号词与易错**（`signals`）
9. **§8 词汇与练习**（`vocab`）

## 3. content 结构（顶层键）

```jsonc
{
  "doc_id": "READ-C-001",
  "pdf_name": "C篇阅读讲解.pdf",
  "eyebrow": "阅读讲解讲义 · READING HANDOUT",
  "footer": "C 篇阅读讲解 · 阅读标注讲义",
  "title": "C 篇阅读讲解",
  "subtitle": "从「垃圾带」到「必须减塑」",
  "desc": "现象 → 反转 → 证据 → 机制 → 主张",
  "meta": [["材料", "常规阅读 第 43 页 · C 篇（4 段 · 说明文）"], ["题型", "细节×2 · 词义×1 · 主旨×1"]],
  "answer_cards": [["Q28", "B", "旧认知被改写：once considered = were long thought"], ...],
  "method_steps": ["① 圈题干关键词", "② 定位信号词句", "③ 逐词同义替换", "④ 按干扰类型排除"],
  "method_note": "四道题走同一条流水线：…",
  "usage": [["§1 材料档案", "四段功能与命题落点…"], ...],
  "oneline": ["一句话记住这篇", "人类垃圾 → 垃圾带 → 有生态 → 但危害 → 所以减塑", "首尾闭环：…"],
  "files_note": "图 1 关键句四层标注 · 图 2 逻辑链与信息点 · 图 3 四题解题链",
  "packet": { ... }, "paras_section": { ... }, "paras": [ ... ],
  "chain": { ... }, "infos": { ... }, "key": { ... },
  "q_section": { ... }, "questions": [ ... ],
  "signals": { ... }, "vocab": { ... },
  "para_pages": [[0,1],[2,3,4]]        // 可选：显式指定每页放哪些段落下标
}
```

### 3.1 `packet`（§1 材料档案）

```jsonc
{
  "num": "01", "title": "材料档案与阅读路径", "en": "MATERIAL & READING ROUTE",
  "accent": "#1D4ED8",
  "intro": "先不动笔翻译，先回答三个问题：…",
  "meta_table":  {"headers": ["段","首句关键词（定位用）","段落功能","命题"],
                  "rows": [["P1","Human-generated garbage …","现象 + 反转","Q28"], ...],
                  "widths": [10,42,32,16],
                  "fonts": [["sans",600,15],["mono",400,13.4],["sans",400,15],["mono",400,14]],
                  "aligns": ["l","l","l","c"]},
  "order_title": "题文同序：读完一段就做一题",
  "order_table": { ... 同上结构 ... },
  "callout": ["为什么先做这张地图", "四段四题一一对应…"],
  "include_first_para": true,          // 把 paras[0] 放进本页，节省一页
  "after_callout": ["第一遍读文只做三件事", "① 在段首写功能标签；② 圈转折词；③ 不查词"]
}
```

### 3.2 `paras`（逐段精读）

```jsonc
{
  "id": "P1", "fn": "现象 + 反转", "color": "#1D4ED8", "bg": "#DCE8FE",
  "en": "Human-generated garbage has created five huge ocean garbage patches …",
  "summary": "垃圾带从哪来、在哪、过去怎么被看、现在发现了什么。",
  "notes": [["首句是因果起点：", "human-generated garbage 说明「因」…"], ...]
}
```

`notes` 的每条是 `[lead, body]`：`lead` 加粗（信号词/动作），`body` 写「为什么」。

### 3.3 `chain`（逻辑链）

```jsonc
{
  "num": "03", "title": "全文逻辑链", "en": "ONE THREAD · 6 NODES", "accent": "#A75C06",
  "intro": "说明文的主线可以压成一句话：…",
  "steps": [["1","现象","人类活动产生垃圾 → 洋流汇聚成五大垃圾带"], ...],   // 6–7 条
  "basis_title": "每一跳的依据（考试时靠这些词确认逻辑）",
  "basis_table": {"headers": ["逻辑跳步","依据信号","说明"], "rows": [...], "widths": [22,34,44],
                  "fonts": [["sans",400,14.6],["mono",400,13.4],["sans",400,14.6]],
                  "aligns": ["l","l","l"]},
  "callout": ["闭环：结尾为什么回到开头", "开头是 …，结尾是 …"],
  "transfer_title": "同一套逻辑链，换个话题也成立",
  "transfer": [["环保类说明文：", "人类行为 → 某处被污染 → …"], ...]
}
```

### 3.4 `infos`（信息点清单）

```jsonc
{
  "num": "04", "title": "信息点清单：13 条，逐条背", "en": "INFORMATION POINTS · I1–I13",
  "accent": "#0E7490",
  "intro": "「信息点」= 原文里能直接支撑某道题的一句话。…",
  "table": {"headers": ["ID","原文锚点","中文信息点","题号"],
            "rows": [["I1","five huge ocean garbage patches","垃圾带位置：洋流交汇、随浪移动","28"], ...],
            "widths": [7,36,42,15], "lh": 25,
            "fonts": [["mono",600,13.4],["mono",400,13.4],["sans",400,14.8],["mono",400,13.4]],
            "aligns": ["l","l","l","c"]},
  "usage_callout": ["表怎么用", "① 做题先按题号找对应…；② 复盘盖住中文列…；③ 背诵…"],
  "direction_title": "信息点之间不是并列，而是有方向的",
  "direction": [["I1 → I2 → I3：", "现象 → 旧认知 → 新发现，构成 P1 的反转。"], ...],
  "recap_callout": ["13 条串成一段话（背下来就是全文复述）", "人类垃圾在洋流交汇处…"]
}
```

### 3.5 `key`（关键句拆解）

```jsonc
{
  "num": "05", "title": "关键句拆解：旧认知 → 转折 → 新发现", "en": "KEY SENTENCE · 5 ROLES",
  "accent": "#6D28D9",
  "intro": "Q28 的依据句是第 1 段的第 2–3 句。…",
  "sentence_label": "依据句 · P1",
  "sentence": "These patches were long thought lifeless, but researchers found a full ecosystem in the largest one.",
  "roles_table": {"headers": ["角色","原文片段","在解题中的功能"],
                  "rows": [["OBJ 讨论对象","These patches","题干问的主体：the patches，全句讨论的出发点"], ...],
                  "widths": [20,34,46],
                  "row_fills": ["#DCE8FE","#FDEFC6","#EBE4FE","#CFF0E2","#DDEEF2"],
                  "bars": ["#1D4ED8","#A75C06","#6D28D9","#06704F","#0E7490"],
                  "fonts": [...], "aligns": ["l","l","l"]},
  "why_title": "为什么 Q28 考这一句",
  "why_bullets": [["旧（were long thought）与新（found）在同一句里：", "命题人可以…"], ...],
  "transfer_title": "这套切法怎么迁移",
  "transfer": [["凡「旧说 + But + 新证据」的句子：", "都按 OLD / MARK / EVID 三段切…"], ...],
  "recap": ["一句话记住这句", "patches 过去被认为「没生命」…"],
  "grammar_title": "从语法上再确认一遍（为什么切得开）",
  "grammar_bullets": [["These patches were long thought lifeless：", "主语 + 被动谓语…"], ...],
  "practice": ["练一练：同一套切法，换一句", "The deep sea was long believed to be lifeless, but …"]
}
```

### 3.6 `questions`（逐题精讲，每题一页）

```jsonc
{
  "no": "Q28", "kind": "细节·判断", "ans": "B", "accent": "#1D4ED8",
  "q": "What do we know about the ocean garbage patches?",
  "keys": ["know about patches", "无段落提示 → 首现处"],
  "loc": "P1 第 2–3 句　信号词 were long thought / But",
  "src": "These patches were long thought lifeless, with plastics and fishing tools harming marine life. But researchers found a full ecosystem in the largest one.",
  "rep_head": ["原文", "选项 ／ 对应", "说明"],
  "rep": [["were long thought", "once considered", "过去被认为"],
          ["lifeless", "have no creatures", "没有生命"],
          ["found a full ecosystem", "（B 项的对照面）", "新发现"]],
  "opts": [["A. formed by natural currents and waves", false, "因果错位", "currents/waves 说的是位置与移动；成因首句已给：human-generated garbage"], ...],
  "walk": [["读题干", "know about patches → 问「已知事实」；题干没有段落提示"], ...],
  "tips": [["题干没有段落提示时：", "按「关键词首现」定位，先看首次出现的段落。"], ...],
  "ext": [["变式 1：", "题干换成 What did researchers find in the largest patch? —— …"], ...],
  "recap": "这题只考一件事：分清「过去被认为」和「现在被证明」。…"
}
```

字段约束：
- `opts` 每条 = `[选项文本, 是否正确(bool), 干扰类型, 判断理由]`；正确项的类型写 `——`。
- `ans` 与 `opts` 中 `true` 的那一项必须一致（`check_content.py` 会校验）。
- 词义题可换成线索表：`rep_head = ["线索", "观察到的结构", "推出"]`。

### 3.7 `signals` / `vocab`

```jsonc
"signals": {"num":"07","title":"信号词清单与易错点","en":"SIGNALS & PITFALLS","accent":"#06704F",
            "intro":"把这表背下来…",
            "signals_table": {"headers":["原文信号词 / 结构","它在提示什么","常出题型","动作"], "rows":[...], "lh":25, ...},
            "verbs_title":"题干动词解码：先看它问什么",
            "verbs_table": {...},
            "selfcheck_title":"易错点自检",
            "selfcheck_table": {...},     // 列：项 / 卷面答案 / 核对 / 结论
            "callout":["三个最容易翻车的点","① … ② … ③ …"]},
"vocab": {"num":"08","title":"词汇语块与练习建议","en":"VOCABULARY & PRACTICE","accent":"#1D4ED8",
          "table": {...}, "practice_title":"练习建议（三次一轮，约 30 分钟）", "practice":[...],
          "self_test_title":"脱稿自测：五个必须能答的问题", "self_test":[...],
          "files_callout":["这份讲义对应的产出文件","handout/X.pdf（本文件）· figures/…"]}
```

## 4. 渲染与分页

```bash
python scripts/engine.py content.json --out ./out --pdf-name "C篇阅读讲解.pdf"
```

- 分页：`page_packet → page_paras`（自动按段落高度装页，阈值 1490 设计单位）→ 之后每节一页 → 每题一页。
- 段落装不下时自动换页；**一页塞不满会显得空**，可通过 `para_pages` 手工指定，或在段落 `notes` 里补到 5–6 条。
- `render()` 每次先清空 `out/pages/*.png`，不会残留旧页；即使只想看位图，PNG 也已经写在 `out/pages/`。
- 输出：`out/pages/p01.png …`、`out/<pdf_name>`（PDF 由这些 2× PNG 合成，`resolution=300`）。

## 5. 排障表

| 现象 | 原因 | 处理 |
|---|---|---|
| 出现 `□` 豆腐块 | 该处字体用了 `mono` 而文本含中文 | 把该列 `fonts` 改成 `sans` |
| 表格文字出框 | `widths` 之和不是 100 或某列太窄 | 调 `widths`（合计 100），必要时缩短文案 |
| 内容溢出页底 | 单页元素太多 | 拆到下一页 / 精简 `notes`、`why_bullets` |
| 页面半页空白 | 内容不够 | 补 `ext`、`callout`、`did you know` 类块，或合并页（`para_pages`） |
| 行首出现 `。，、` | 旧版换行未做避头尾 | 用本技能的 `engine.py`（已内置避头尾） |
| PDF 变黑白/糊 | 用了 1× PNG 且低 dpi | 保持 2× + `resolution=300` |
| 中文显示为宋体但引号很宽 | `’`（U+2019）在部分字体里字距异常 | 引擎已自动替换为 ASCII `'` |
| Pillow 报 `cannot write mode P` | 图片带调色板 | 引擎内部已转 `RGB` |
