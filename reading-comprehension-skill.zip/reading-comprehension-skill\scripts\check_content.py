#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""内容体检：在渲染前找出「讲不清 / 会豆腐块 / 会出框」的问题。

用法：
    python scripts/check_content.py content.json
    python scripts/check_content.py content.py

约定（与 engine.py 一致）：
    opts 每条 = [选项文本, 标记("√"/"×"), 干扰类型, 判断理由]
    table.widths 是相对权重（引擎内部归一化到 1084），不必等于 100

退出码：0 = 通过（可能有警告），1 = 有错误需要修。
"""
import importlib.util
import json
import os
import sys

CJK_RANGES = [(0x2E80, 0x9FFF), (0x3000, 0x303F), (0xFF00, 0xFFEF), (0x2018, 0x201F)]
OK_MARKS = set("√✓")
NG_MARKS = set("×✗")
WEAK_TYPES = {"", "——", "-", "—", "错误", "不对", "与原文不符", "不符", "其它", "其他"}
GENERIC_WHY = {"与原文不符", "不符合原文", "错误", ""}


def has_cjk(s):
    return isinstance(s, str) and any(
        any(lo <= ord(ch) <= hi for lo, hi in CJK_RANGES) for ch in s
    )


def first_letter(s):
    for ch in str(s):
        if ch.upper() in "ABCD":
            return ch.upper()
    return ""


def load(path):
    if path.endswith(".json"):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    spec = importlib.util.spec_from_file_location("content_mod", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.CONTENT


class Report:
    def __init__(self):
        self.errs, self.warns = [], []

    def err(self, where, msg):
        self.errs.append((where, msg))

    def warn(self, where, msg):
        self.warns.append((where, msg))

    def dump(self):
        for w, m in self.errs:
            print(f"[ERROR] {w}: {m}")
        for w, m in self.warns:
            print(f"[warn ] {w}: {m}")
        print(f"\n{len(self.errs)} error(s), {len(self.warns)} warning(s)")
        return 1 if self.errs else 0


def check_table(rep, where, t, expect_cols=None, mono_cjk_is_error=True):
    if not isinstance(t, dict):
        rep.err(where, "表格必须是 dict")
        return
    for k in ("headers", "rows", "widths", "fonts", "aligns"):
        if k not in t:
            rep.err(where, f"缺字段 {k}")
            return
    ncol = len(t["headers"])
    if expect_cols and ncol != expect_cols:
        rep.err(where, f"应为 {expect_cols} 列，实际 {ncol} 列")
    if len(t["widths"]) != ncol:
        rep.err(where, f"widths 个数 {len(t['widths'])} ≠ 列数 {ncol}")
    elif any(w <= 0 for w in t["widths"]):
        rep.err(where, "widths 里有非正数")
    elif ncol > 2 and min(t["widths"]) / sum(t["widths"]) < 0.04:
        rep.warn(where, f"最窄列占比 {(min(t['widths']) / sum(t['widths'])):.1%}，容易挤")
    if len(t["fonts"]) != ncol:
        rep.err(where, f"fonts 个数 {len(t['fonts'])} ≠ 列数 {ncol}")
    if len(t["aligns"]) != ncol:
        rep.err(where, f"aligns 个数 {len(t['aligns'])} ≠ 列数 {ncol}")
    for ri, row in enumerate(t["rows"]):
        if len(row) != ncol:
            rep.err(f"{where}/第{ri + 1}行", f"{len(row)} 个单元格 ≠ {ncol} 列")
            continue
        for ci, cell in enumerate(row):
            if ci < len(t["fonts"]) and t["fonts"][ci][0] == "mono" and has_cjk(cell):
                msg = f"含中文却用 mono 字体（会渲染成 □）：{str(cell)[:24]}"
                if mono_cjk_is_error:
                    rep.err(f"{where}/第{ri + 1}行第{ci + 1}列", msg)
                else:
                    rep.warn(f"{where}/第{ri + 1}行第{ci + 1}列", msg)


def check_question(rep, i, q):
    where = f"questions[{i}]"
    for k in ("no", "q", "ans", "kind", "opts", "walk", "keys", "loc", "src", "recap"):
        if k not in q or q.get(k) in (None, "", []):
            rep.err(where, f"缺字段 {k}")

    opts = q.get("opts") or []
    if len(opts) != 4:
        rep.err(where, f"opts 应为 4 项，实际 {len(opts)}")
    ok_idx, seen_marks = [], []
    for j, o in enumerate(opts):
        if len(o) < 4:
            rep.err(f"{where}.opts[{j}]", "应为 [文本, 标记√/×, 干扰类型, 判断理由]")
            continue
        text, mark, kind, why = o[0], str(o[1]).strip(), str(o[2]).strip(), str(o[3]).strip()
        seen_marks.append(mark)
        if mark in OK_MARKS:
            ok_idx.append(j)
            if kind not in ("——", "-", "—", ""):
                rep.warn(f"{where}.opts[{j}]", f"正确项的干扰类型建议写「——」，现为「{kind}」")
        elif mark in NG_MARKS:
            if kind in WEAK_TYPES:
                rep.err(f"{where}.opts[{j}]", f"错项没有命名干扰类型（{text[:20]}）")
            if why in GENERIC_WHY or len(why) < 8:
                rep.err(f"{where}.opts[{j}]", f"判断理由太空（{text[:20]}）")
        else:
            rep.err(f"{where}.opts[{j}]", f"标记应为 √ 或 ×，现为「{mark}」")
        if not text.strip():
            rep.err(f"{where}.opts[{j}]", "选项文本为空")

    if len(ok_idx) != 1:
        rep.err(where, f"正确项应恰好 1 个，实际 {len(ok_idx)} 个（标记 {seen_marks}）")
    else:
        letter = "ABCD"[ok_idx[0]]
        if first_letter(q.get("ans", "")) != letter:
            rep.err(where, f"ans=「{q.get('ans')}」与正确项 {letter} 不一致")
        else:
            for j in range(4):
                if j != ok_idx[0] and f"{'ABCD'[j]}." not in str(opts[j][0]):
                    rep.warn(f"{where}.opts[{j}]", "选项文本缺 A./B./C./D. 前缀")

    walk = q.get("walk") or []
    if len(walk) < 3:
        rep.warn(where, "解题实录少于 3 步（建议 4 步：读题干 / 扫原文 / 读定位句 / 对选项）")
    for j, w in enumerate(walk):
        if not isinstance(w, (list, tuple)) or len(w) != 2:
            rep.err(f"{where}.walk[{j}]", "应为 [动作, 说明]")
    if not (q.get("rep") or []):
        rep.warn(where, "同义替换表为空（正确答案的生成过程应逐词对照）")
    if len(q.get("ext") or []) < 2:
        rep.warn(where, "同类变式建议 ≥ 2 条")
    if not q.get("src") or len(str(q["src"])) < 30:
        rep.warn(where, "证据句太短，确认是否摘录完整")


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__)
        return 1
    path = argv[0]
    if not os.path.exists(path):
        print(f"找不到文件：{path}")
        return 1
    C = load(path)
    rep = Report()

    # 顶层
    for k in ("title", "pdf_name", "footer", "questions", "paras"):
        if k not in C:
            rep.err("顶层", f"缺字段 {k}")
    if not C.get("questions"):
        rep.err("顶层", "questions 为空：至少需要 1 道题")
    if not C.get("paras"):
        rep.err("顶层", "paras 为空：逐段精读是讲义的骨架")

    # 封面答案速览（[题号, 答案, 理由] 或 [题号, 答案, 理由, 颜色]）
    cards = C.get("answer_cards") or []
    if cards and len(cards) != len(C.get("questions") or []):
        rep.warn("顶层", "answer_cards 数量与 questions 数量不一致（封面答案速览会缺卡）")
    for j, card in enumerate(cards):
        if len(card) not in (3, 4):
            rep.err(f"answer_cards[{j}]", "应为 [题号, 答案, 一句话理由(, 颜色)]")

    # 材料档案
    if "packet" in C:
        p = C["packet"]
        for k in ("num", "title", "meta_table", "order_table"):
            if k not in p:
                rep.err("packet", f"缺字段 {k}")
        if "meta_table" in p:
            check_table(rep, "packet.meta_table", p["meta_table"], 4)
        if "order_table" in p:
            check_table(rep, "packet.order_table", p["order_table"], 4)

    # 段落
    for i, para in enumerate(C.get("paras") or []):
        where = f"paras[{i}]"
        for k in ("id", "fn", "en", "summary", "notes"):
            if not para.get(k):
                rep.err(where, f"缺字段 {k}")
        if len(para.get("notes") or []) < 3:
            rep.warn(where, "讲解条目建议 ≥ 3 条（信号词/动作 + 为什么）")
        for j, n in enumerate(para.get("notes") or []):
            if not isinstance(n, (list, tuple)) or len(n) != 2:
                rep.err(f"{where}.notes[{j}]", "应为 [lead, body]")

    # 逻辑链
    if "chain" in C:
        ch = C["chain"]
        steps = ch.get("steps") or []
        if not (4 <= len(steps) <= 8):
            rep.warn("chain.steps", f"节点数 {len(steps)}（建议 5–7）")
        for i, s in enumerate(steps):
            if len(s) not in (3, 4):
                rep.err(f"chain.steps[{i}]", "应为 [序号, 标签, 一句说明(, 颜色)]")
        if "basis_table" in ch:
            check_table(rep, "chain.basis_table", ch["basis_table"], 3)

    # 信息点
    if "infos" in C:
        inf = C["infos"]
        check_table(rep, "infos.table", inf.get("table", {}), 4)
        rows = inf.get("table", {}).get("rows") or []
        if not (6 <= len(rows) <= 20):
            rep.warn("infos.table", f"信息点 {len(rows)} 条（建议 10–15）")

    # 关键句
    if "key" in C:
        k = C["key"]
        for f in ("sentence", "roles_table", "why_bullets", "recap"):
            if not k.get(f):
                rep.err("key", f"缺字段 {f}")
        if k.get("roles_table"):
            check_table(rep, "key.roles_table", k["roles_table"], 3)
        sentence = str(k.get("sentence", "")).replace("’", "'")
        for row in (k.get("roles_table") or {}).get("rows") or []:
            if len(row) < 2:
                continue
            frag = str(row[1]).strip().replace("’", "'")
            if frag and frag not in sentence and "…" not in frag and "..." not in frag:
                rep.err("key.roles_table", f"片段「{frag[:24]}」不在依据句里（应原样摘录）")

    # 逐题
    for i, q in enumerate(C.get("questions") or []):
        check_question(rep, i, q)

    # 其余表格（含中文给 mono 只报警告，因为这类表述多为英文为主）
    for sec in ("signals", "vocab"):
        if sec in C:
            for key, t in C[sec].items():
                if isinstance(t, dict) and "headers" in t:
                    check_table(rep, f"{sec}.{key}", t, mono_cjk_is_error=False)

    # 字体可用性
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import kit  # noqa: F401
        missing = [f for f, p in kit.FONT_PATHS.items() if not p]
        if missing:
            rep.warn("字体", f"未找到 {missing}，会退回系统默认字体（可能影响中文排版）")
    except Exception as e:  # kit 依赖 Pillow
        rep.warn("字体", f"无法加载 kit.py 检查字体：{e}")

    print(f"文件：{path}")
    print(f"题目 {len(C.get('questions') or [])} 道，段落 {len(C.get('paras') or [])} 段，"
          f"信息点 {len((C.get('infos', {}).get('table', {}) or {}).get('rows') or [])} 条")
    print()
    return rep.dump()


if __name__ == "__main__":
    raise SystemExit(main())
